#include <iostream>
using namespace std;

// in beginning front and rear is -1
// one enqueue, dequeue, empty, display
// enqueue give index to enque the element
const int size=5;
class List
{
	 public:
	 	int arr[size];
	 	int front;
	 	int rear;
	 	
	 	
	 	List()
		{
			front = 0;
			rear  = 0;
		}
		 
		 void enqueue(int value)
		 {
		 	if(rear==size-1)
		 	{
		 		return ;
			}
		 	arr[rear] = value;
		 	rear++;
		 	
		 }
		 
		 
		 
		 void dequeue()
		 {
		 	if(rear == 0 || front==rear)
		 	{
		 		cout<<"list is empty!"<<endl;
		 		return;
			}
			 
		 	front++;
		 	
		 }
		 bool isFull()
		 {
		 	if(rear==size-1)
		 	{
		 		return true;
			}
			else
			{
				return false;
			}
		 }
		 
		 void display()
		 {
		 	if(rear == 0 || front == rear)
		 	{
		 		return;
			}
			else
			{
			
		 	cout<<"displaying the items"<<endl;
		 	
		 	for(int i=front; i<rear; i++)
		 	{
		 		cout<<arr[i]<<endl;
		 	
			}
		}
		 }
		 
		 
		 
};

int main()
{
	List l1;
	l1.enqueue(25);
	l1.enqueue(45);
	l1.enqueue(65);
	l1.enqueue(76);
	l1.enqueue(87);
	
	l1.display();
	
	l1.dequeue();
	l1.dequeue();
	
	l1.display();
	
	cout<<"chcking if queue is full or not!"<<endl;
	cout<<l1.isFull();
	
	
	
	
}